#define MACHVEC_PLATFORM_NAME		hpzx1
#define MACHVEC_PLATFORM_HEADER		<asm/machvec_hpzx1.h>
#include <asm/machvec_init.h>
