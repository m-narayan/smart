define(
({
	createLinkTitle: "Hivatkozás tulajdonságai",
	insertImageTitle: "Kép tulajdonságai",
	url: "URL:",
	text: "Leírás:",
	target: "Cél:",
	set: "Beállítás",
	currentWindow: "Aktuális ablak",
	parentWindow: "Szülő ablak",
	topWindow: "Legfelső szintű ablak",
	newWindow: "Új ablak"
})
);
